package com.example.tugasbesar1;

public interface Presenter  {
    void changeMessage(String Message);
    void tambah (Angka angka);
    void delete (int i);
    void setOutput(double res);
}