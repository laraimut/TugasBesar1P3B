package com.example.tugasbesar1;

public interface FragmentListener {
    void changePage(int page);


}